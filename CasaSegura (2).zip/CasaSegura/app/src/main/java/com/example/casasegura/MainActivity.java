package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.widget.LinearLayout;

/**
 * La MainActivity unicamente mostrara la imagen/logo de nuestra aplicacion
 * y despues de 4 segundos se movera a la siguiente actividad que es IniciarSesionActivity
 *
 * @author  Kevin Lezana
 * @version 1.0
 * @since   2020-07-31
 */

public class MainActivity extends AppCompatActivity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        * Aca se crea la animacion y tambien se decide el tiempo de espera
        * @param layout = este es id de nuestro activity_main.xml
        *
        * */
        LinearLayout linearLayout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) linearLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(2000);
        animationDrawable.start();

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), IniciarSesionActivity.class);

                startActivity(intent);
                finish();
            }
        }, 4000);
    }


}
