package com.example.casasegura.cargando;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;

import com.example.casasegura.R;

public class CargandoDialog {
    public Activity activity;
    public AlertDialog alertDialog;

    public CargandoDialog(Activity myActivity){
        this.activity = myActivity;

    }

    public void abrirAlertDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);

        LayoutInflater inflater = activity.getLayoutInflater();
        builder.setView(inflater.inflate(R.layout.loading_dialog,null));
        builder.setCancelable(false);
        alertDialog = builder.create();
        alertDialog.show();
    }

    public void cerrarAlertDialog(){
        alertDialog.dismiss();
    }
}
