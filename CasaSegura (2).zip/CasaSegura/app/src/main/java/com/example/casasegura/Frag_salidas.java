package com.example.casasegura;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.casasegura.modeloVO.registroVO;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Frag_salidas extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    private ListView lista;
    RequestQueue requestQueue;
    //public static final String IP_SERVER = "http://192.168.0.12/";
    public static final String IP_SERVER = IniciarSesionActivity.IP_SERVER;
    JsonObjectRequest jsonObjectRequest;
    ArrayList<String> listaDatos;
    ArrayList<registroVO> listaregistro;
    private int id;

    public Frag_salidas() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_frag_salidas, container, false);
        lista = view.findViewById(R.id.listaMostrar);
        requestQueue = Volley.newRequestQueue(getContext());
        traerDatos();
        consultaRegistrosEntradas();

        return view;
    }

    public void traerDatos(){
        this.id= getArguments().getInt("id");
    }

    private void consultaRegistrosEntradas() {
        String url;
        url = IP_SERVER+"/php_android/obtenerhistorial.php?fk_idusuario="+this.id+"&fk_idtblcheck=2";
        jsonObjectRequest= new JsonObjectRequest(Request.Method.GET,url,null,this,this );
        requestQueue.add(jsonObjectRequest);

    }
    @Override
    public void onErrorResponse(VolleyError error) {
        if (error instanceof TimeoutError) {
            Toast.makeText(getContext(), "error_network_timeout", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ServerError) {
            Toast.makeText(getContext(), "error_server", Toast.LENGTH_SHORT).show();
        } else if (error instanceof NetworkError) {
            Toast.makeText(getContext(), "network error", Toast.LENGTH_SHORT).show();
        } else if (error instanceof ParseError) {
            Toast.makeText(getContext(), "parse error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "algun otro error", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onResponse(JSONObject response) {
        registroVO registroVo = null;

        JSONArray jsonArray = response.optJSONArray("registro");
        listaregistro = new ArrayList<>();
        try{
            for (int i = 0; i<jsonArray.length(); i ++){
                registroVo = new registroVO();
                JSONObject jsonObject = null;
                jsonObject = jsonArray.getJSONObject(i);

                registroVo.setToken(jsonObject.optString("fk_idtoken"));
                registroVo.setFecha(jsonObject.optString("fecha"));
                registroVo.setHora(jsonObject.optString("hora"));
                listaregistro.add(registroVo);

            }

            listaDatos = new ArrayList<>();
            for (int i = 0; i<listaregistro.size(); i++){
                listaDatos.add(listaregistro.get(i).getToken()+" - "+listaregistro.get(i).getFecha()+" - "+listaregistro.get(i).getHora());
            }

            ArrayAdapter adapter = new ArrayAdapter(getContext(), android.R.layout.simple_list_item_1, listaDatos);
            lista.setAdapter(adapter);
            lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //  Toast.makeText(MainActivity.this, "A pulsado "+datos.get(position), Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(getContext(), DetallesTokenActivity.class);
                    intent.putExtra("id_tbltoken", listaregistro.get(position).getToken());
                    startActivity(intent);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
