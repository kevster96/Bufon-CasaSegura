package com.example.casasegura.modeloVO;

public class registroVO {
    private String token;
    private String fecha;
    private String hora;

    public registroVO() {

    }

    public registroVO(String token, String fecha, String hora) {
        this.token = token;
        this.fecha = fecha;
        this.hora = hora;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
}