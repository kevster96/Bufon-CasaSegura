package com.example.casasegura;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class RegistrosActivity extends AppCompatActivity {
    Fragment frag_entradas, frag_salidas;
    FragmentTransaction transaction;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registros);
        traerDatos();
        startFrag_salidas();
        startFrag_Entradas();
    }

    public void traerDatos(){
        Bundle bundle =getIntent().getExtras();
        this.id= bundle.getInt("id");

    }



    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btnEntradas:
                startFrag_Entradas();
                break;
            case R.id.btnSalidas:
                startFrag_salidas();
                break;

        }
    }

    public void startFrag_Entradas(){
        Bundle bundle1 = new Bundle();
        bundle1.putInt("id",id);
        frag_entradas = new Frag_entradas();
        frag_entradas.setArguments(bundle1);
        getSupportFragmentManager().beginTransaction().add(R.id.contenedorID,frag_entradas).commit();
    }

    public void startFrag_salidas(){
        Bundle bundle1 = new Bundle();
        bundle1.putInt("id",id);
        frag_salidas = new Frag_salidas();
        frag_salidas.setArguments(bundle1);
        getSupportFragmentManager().beginTransaction().add(R.id.contenedorID,frag_salidas).commit();
    }

}
