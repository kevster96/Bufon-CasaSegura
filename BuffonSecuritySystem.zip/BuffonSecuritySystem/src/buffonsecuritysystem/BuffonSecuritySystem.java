/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package buffonsecuritysystem;

import control.ControladorAdmin;
import control.ControladorAdminCrear;
import control.ControladorAdminEditar;
import control.ControladorAdminResBorrar;
import control.ControladorAdminResCrear;
import control.ControladorAdminResEditar;
import control.ControladorLogin;
import control.controlPrincipal;
import control.controladorAdminBorrar;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import modelo.VisitaDAO;
import modelo.VisitaVO;
import vista.MenuAdminBorrar;
import vista.MenuAdminPrincipal;
import vista.MenuAdminBuscar;
import vista.MenuAdminCrear;
import vista.MenuAdminResidenteBorrar;
import vista.MenuAdminResidenteBuscar;
import vista.MenuAdminResidenteCrear;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */


//Actividad principal que hace referencia a los controladores y cada vista de la aplicacion
public class BuffonSecuritySystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Este es un cambio
        
        //Referencia a cada una de las vistas
        menuLogin lg = new menuLogin();
        menuPrincipal mp = new menuPrincipal();
        MenuAdminBorrar mab = new MenuAdminBorrar();
        MenuAdminCrear mac = new MenuAdminCrear();
        
        MenuAdminResidenteBorrar marb = new MenuAdminResidenteBorrar();
        MenuAdminResidenteBuscar maru = new MenuAdminResidenteBuscar();
        MenuAdminResidenteCrear marc = new MenuAdminResidenteCrear();
        
        MenuAdminBuscar ma = new MenuAdminBuscar();
        MenuAdminPrincipal map = new MenuAdminPrincipal();
        
        //Referencia a UsuarioDAO, UsuarioVO, VisitaDAO y VisitaVo para 
        //obtener los setters y getters junto a los metodos de la aplicacion.
        VisitaDAO vd = new VisitaDAO();
        VisitaVO vv = new VisitaVO();
        UsuarioVO uvo= new UsuarioVO();
        UsuarioDAO ud = new UsuarioDAO();
        
        //Referencia a cada uno de los controladores con su constructor
        //para obtener las ventanas con sus metodos y referencias a cada una de las
        //ventanas
        ControladorLogin clgn = new ControladorLogin(lg,uvo,ud, map, mp);
        controlPrincipal cpl = new controlPrincipal(mp,vd,vv, uvo,ud, lg);
        ControladorAdmin ca = new ControladorAdmin(ud, ma, uvo,map, mac, mab, marb, maru, marc,lg);
        ControladorAdminResCrear crc = new ControladorAdminResCrear(uvo, ud, marc, map, lg);
        ControladorAdminResEditar care = new ControladorAdminResEditar(uvo, ud, maru, map, lg);
        ControladorAdminResBorrar carb = new ControladorAdminResBorrar(uvo, ud, marb, map, lg);
        controladorAdminBorrar adb = new controladorAdminBorrar(ud, uvo, mab, map, lg);
        ControladorAdminEditar cae = new ControladorAdminEditar(ud,uvo, ma, map, lg);
        ControladorAdminCrear cac = new ControladorAdminCrear(ud, uvo,mac, map, lg);
        
        //Inicializamos la ventana inicial del login
        lg.setVisible(true);
    }
    
}
