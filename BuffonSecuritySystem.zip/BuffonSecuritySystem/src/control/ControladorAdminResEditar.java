/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminPrincipal;
import vista.MenuAdminResidenteBuscar;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorAdminResEditar implements ActionListener, MouseListener, WindowListener{
        
    UsuarioVO uv = new UsuarioVO();
    UsuarioDAO ud = new UsuarioDAO();
    
    MenuAdminResidenteBuscar mrb = new MenuAdminResidenteBuscar();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();   
    int id =0;
    
    public ControladorAdminResEditar(UsuarioVO uv, UsuarioDAO ud, MenuAdminResidenteBuscar mrb, MenuAdminPrincipal mp, menuLogin ml){
        this.uv = uv;
        this.ud = ud;
        this.mp= mp;
        this.ml = ml;
        this.mrb = mrb;
        
        mrb.jbtnBuscar.addActionListener(this);
        mrb.jbtnEditar.addActionListener(this);
        mrb.jbtnCerrarSesion.addActionListener(this);
        mrb.jbtnMenuPrincipal.addActionListener(this);
        
        mrb.jtable.addMouseListener(this);
        mrb.addWindowListener(this);
        
    }
    
    private boolean isEmpty(){
        if("".equals(uv.getId())){
            mrb.joptionGuardar.showMessageDialog(null, "Por favor ingrese el ID");
            return false;

        }
        
         if("".equals(uv.getNombre())){
            mrb.joptionGuardar.showMessageDialog(null, "Por favor ingrese el nombre");
            return false;
        }
        if("".equals(uv.getApellido())){
            mrb.joptionGuardar.showMessageDialog(null, "Por favor ingrese el apellido");
            return false;
        }if("".equals(uv.getPassw())){
            mrb.joptionGuardar.showMessageDialog(null, "Por favor ingrese la nueva contraseña");
            return false;
        }
        if("".equals(uv.getUsuario())){
            mrb.joptionGuardar.showMessageDialog(null, "Por favor ingrese el usuario");
            return false;
        }
        else{
            return true;
        }
    }
    
    private void vaciarTexto(){
        mrb.jtxtID.setText("");
        mrb.jtxtNombre.setText("");
        mrb.jtxtPassw.setText("");
        mrb.jtxtApellido.setText("");
    }

    public void buscarResidente(){
        id=uv.getId();
        uv.setId(Integer.parseInt(this.mrb.jtxtID.getText()));
        
        ud.obtenerResidente(uv);
        mrb.jtxtNombre.setText(uv.getNombre());
        mrb.jtxtApellido.setText(uv.getApellido());
        mrb.jtxtPassw.setText(uv.getPassw());
        mrb.jtxtUsuario.setText(uv.getUsuario());
        mrb.jcmboEstadoUsuario.setSelectedIndex(uv.getEstado());
    }
    
    public void editarResidente(){
        uv.setId(Integer.parseInt(mrb.jtxtID.getText()));
        uv.setNombre(mrb.jtxtNombre.getText());
        uv.setApellido(mrb.jtxtApellido.getText());
        uv.setPassw(mrb.jtxtPassw.getText());
        uv.setUsuario(mrb.jtxtUsuario.getText());
        uv.setEstado(mrb.jcmboEstadoUsuario.getSelectedIndex());
        uv.setFk_usuario(id);
        
        this.ud.modificarResidente(uv);
        
        this.vaciarTexto();
        
    }
    
    public void getFila(){
        int row= mrb.jtable.getSelectedRow();
        String value = String.valueOf(mrb.jtable.getValueAt(row, 0));
        
        String value2 = String.valueOf(mrb.jtable.getValueAt(row, 1));
        
        String value3 = String.valueOf(mrb.jtable.getValueAt(row, 2));
        
        String value4 = String.valueOf(mrb.jtable.getValueAt(row, 3));
        
        String value5 = String.valueOf(mrb.jtable.getValueAt(row, 4));
        
        String value6 = String.valueOf(mrb.jtable.getValueAt(row, 5));
        
        
        
        int estado = Integer.parseInt(value6);
        mrb.jtxtID.setText(value);
        mrb.jtxtNombre.setText(value2);
        mrb.jtxtApellido.setText(value3);
        mrb.jtxtUsuario.setText(value4);
        mrb.jtxtPassw.setText(value5);
        mrb.jcmboEstadoUsuario.setSelectedIndex(estado);
        
        uv.setNombre(String.valueOf(mrb.jtxtNombre.getText()));
        uv.setApellido(String.valueOf(mrb.jtxtApellido.getText()));
    }
    
        private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Administrador ID");
            
            for(UsuarioVO v : this.ud.consultarResidente()){
                m.addRow(new Object[]{v.getId(), v.getNombre(), v.getApellido(), v.getUsuario(),
                v.getPassw(), v.getEstado(), v.getFk_usuario()});
            }
            mrb.jtable.setModel(m);
        }
        
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== mrb.jbtnBuscar){
            
            this.buscarResidente(); 
            this.mostrarDB();
        }
        if(e.getSource() == mrb.jbtnEditar){
            this.editarResidente();
            this.mostrarDB();
        }
        if(e.getSource() == mrb.jbtnCerrarSesion){
            mrb.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }if(e.getSource()== mrb.jbtnMenuPrincipal){
            mrb.setVisible(false);
            mp.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.getFila();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
    }

    @Override
    public void windowClosed(WindowEvent e) {
        
    }

    @Override
    public void windowIconified(WindowEvent e) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        
    }

    @Override
    public void windowActivated(WindowEvent e) {
        
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        
    }
}
