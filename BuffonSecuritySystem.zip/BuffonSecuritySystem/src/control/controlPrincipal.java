/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import modelo.VisitaDAO;
import modelo.VisitaVO;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class controlPrincipal implements ActionListener{

    
    //Referencia al menu principal y al menu login
    menuPrincipal mp = new menuPrincipal();
    menuLogin ml = new menuLogin();
    
    //refernecia a los metodos y setters y getters de Visita
    VisitaDAO vd = new VisitaDAO();
    VisitaVO vv = new VisitaVO();
    
    //referencia a los metodos y setters and getters de usuario
    UsuarioVO uv = new UsuarioVO();
    UsuarioDAO ud = new UsuarioDAO();
   // para poder obtener el ID del guardian
    int id = 0;
    //para obtener el ID del residente
    int id_usuario = 0;
    
    //controlador principal, hacemos referencia a las clases.
    public controlPrincipal(menuPrincipal mp, VisitaDAO vd, VisitaVO vv, UsuarioVO uv, UsuarioDAO ud, menuLogin ml) {
        this.mp=mp;
        this.ml=ml;
        this.ud=ud;
        this.uv=uv;
        this.vd=vd;
        this.vv=vv;
        this.mp.jbtnIngresarDatos.addActionListener(this);
        this.mp.jbtnCerrarSesion.addActionListener(this);
        this.mp.jbtnCargar.addActionListener(this);
    }
    
    private void getNameandDPI(){
        //Hacemos set al token
        this.vv.setToken(this.mp.jtxtCodigoUnico.getText());
        //Obtenemos el nombre del visitante
        String nombre1 = this.vd.getName(vv);
        //obtenemos el DPI
        long DPI = this.vd.getDPI(vv);
        // Convertimos los valores de los getters a String
        String nombre= String.valueOf(vv.getNombre());
        String apellido=String.valueOf(vv.getApellido());
        String dpi = String.valueOf(vv.getDPI());
        
        //Llenamos la vista
        mp.jtxtNombre.setText(nombre);
        mp.jtxtApellido.setText(apellido);
        mp.jtxtDPI.setText(dpi);
    }

    private void guardarRegistro(){
        //Hacemos referencia a la fecha de hoy
        long millis = System.currentTimeMillis();
        java.sql.Date date = new java.sql.Date(millis);
        //Convertimos la fecha de un long a un String
        String dtt = date.toString();
        //Obtenemos el ID del residente
        id_usuario = this.vd.obtenerUsuarioID(vv);
        
        //Obtenemos el ID del policia
        id = this.uv.getId();
        //Llenamos los datos de los setters
        this.uv.setFk_usuario(id_usuario);
        this.vv.setToken(this.mp.jtxtCodigoUnico.getText());
        this.uv.setId(id);
        //Se utiliza el combo para obtener si es entrada o salida
        this.vv.setEntradasalida(mp.jcmbUserPass.getSelectedIndex()+1);
        
        //Se obtiene la fecha para comparar y validar que sea la misma que en la aplicacion android
        String newfecha = vd.obtenerFecha(vv);
        //Se compara la fecha de acceso del token a la fecha del dia actual, para validar que se pueda ingresar la visita
        if(newfecha.equals(dtt) ){
            //llamamos el metodo validar visita
            vd.validarVisita(vv, uv);
            //Se muestra el joptionPane validando el registro
            mp.joptionValidacion.showMessageDialog(null, "Se ha guardado el registro");
        }else{
            //Se muestra la fecha en la cual el token se puede utilizar
            mp.joptionValidacion.showMessageDialog(null, "El codigo no se puede utilizar hoy, se debe utilizar el: "+vv.getFecha());
        }
        
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == mp.jbtnCargar){
            //Con el boton cargar se hace referencia a la obtencion de datos
            this.getNameandDPI();
        }
        if(e.getSource()== mp.jbtnIngresarDatos){
            //Se guarda el registro en la base de datos
            this.guardarRegistro();
        }
        if(e.getSource() == mp.jbtnCerrarSesion){
            //Si el boton cerrar sesion se presiona, se cierra la ventana
            //se abre la ventana log in y setteamos los campos de texto
            //a vacios
            mp.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }
    }
        
    }



