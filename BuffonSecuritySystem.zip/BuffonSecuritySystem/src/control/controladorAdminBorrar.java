/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminBorrar;
import vista.MenuAdminBuscar;
import vista.MenuAdminCrear;
import vista.MenuAdminPrincipal;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class controladorAdminBorrar implements ActionListener, MouseListener, WindowListener{
    
    UsuarioDAO ud = new UsuarioDAO();
    MenuAdminBorrar mab = new MenuAdminBorrar();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();
    UsuarioVO uv = new UsuarioVO();
    
    
    public controladorAdminBorrar(UsuarioDAO ud, UsuarioVO uv, MenuAdminBorrar mab, MenuAdminPrincipal mp, menuLogin ml){
        this.ud = ud;
        this.mp=mp;
        this.ml=ml;
        this.uv = uv;
        this.mab = mab;
        
        this.mab.jbtnBorrar.addActionListener(this);
        this.mab.jbtnBuscar.addActionListener(this);
        this.mab.jbtnCerrarSesion.addActionListener(this);
        this.mab.jbtnMenuPrincipal.addActionListener(this);
     
        this.mab.jtable.addMouseListener(this);
        this.mab.addWindowListener(this);
    }

        private void cargarUsuarioBorrar(){
        String name;
        uv.setId(Integer.parseInt(mab.jtxtID.getText()));
        name = ud.obtenerNombre(uv);
        String nombre = uv.getNombre();
        String apellido = uv.getApellido();
        String usuario = uv.getUsuario();
        String passw = uv.getPassw();
        int acceso = uv.getAcceso();
        int estado = uv.getEstado();
        
        mab.jtxtNombre.setText(nombre);
        mab.jtxtApellido.setText(apellido);
        mab.jtxtPassw.setText(passw);
        mab.jtxtUsuario.setText(usuario);
        mab.jcmboAcceso.setSelectedIndex(acceso-1);
        mab.jcmboEstadoUsuario.setSelectedIndex(estado);
    }
        
        private void eliminarPorID(){
        uv.setId(Integer.parseInt(mab.jtxtID.getText()));
        ud.Eliminar(uv);
    }
    
    private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Acceso");
            
            for(UsuarioVO v : this.ud.consultarTabla()){
                m.addRow(new Object[]{v.getId(), v.getNombre(), v.getApellido(), v.getUsuario(),
                v.getPassw(), v.getEstado(), v.getAcceso()});
            }
            mab.jtable.setModel(m);
        }        
        
        public void getFila(){
        int row= mab.jtable.getSelectedRow();
        String value = String.valueOf(mab.jtable.getValueAt(row, 0));
        
        String value2 = String.valueOf(mab.jtable.getValueAt(row, 1));
        
        String value3 = String.valueOf(mab.jtable.getValueAt(row, 2));
        
        String value4 = String.valueOf(mab.jtable.getValueAt(row, 3));
        
        String value5 = String.valueOf(mab.jtable.getValueAt(row, 4));
        
        String value6 = String.valueOf(mab.jtable.getValueAt(row, 5));
        
        String value7 = String.valueOf(mab.jtable.getValueAt(row, 6));
        
        int estado = Integer.parseInt(value6);
        int acceso = Integer.parseInt(value7);
        mab.jtxtID.setText(value);
        mab.jtxtNombre.setText(value2);
        mab.jtxtApellido.setText(value3);
        mab.jtxtUsuario.setText(value4);
        mab.jtxtPassw.setText(value5);
        mab.jcmboAcceso.setSelectedIndex(acceso);
        mab.jcmboEstadoUsuario.setSelectedIndex(estado);
        }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== mab.jbtnBorrar){
            this.eliminarPorID();
            this.mostrarDB();
        }
        if(e.getSource()== mab.jbtnBuscar){
            try{
            this.cargarUsuarioBorrar();   
            this.mostrarDB();
            mab.joptionBorrar.showMessageDialog(null, "Ha borrado el usuario: "+uv.getUsuario()+ " exitosamente");
            }catch(Exception a){
             mab.joptionBorrar.showMessageDialog(null, "Ha ocurrido un erro inesperado: "+a);   
            }

        }
        if(e.getSource()== mab.jbtnCerrarSesion){
            this.mab.setVisible(false);
            this.ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }
        if(e.getSource() == mab.jbtnMenuPrincipal){
            this.mab.setVisible(false);
            this.mp.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.getFila();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
       this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
       
    }

    @Override
    public void windowClosed(WindowEvent e) {
       
    }

    @Override
    public void windowIconified(WindowEvent e) {
       
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
       
    }

    @Override
    public void windowActivated(WindowEvent e) {
       
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
       
    }
    
}
