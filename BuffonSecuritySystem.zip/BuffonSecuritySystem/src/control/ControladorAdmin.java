/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminBorrar;
import vista.MenuAdminBuscar;
import vista.MenuAdminCrear;
import vista.MenuAdminPrincipal;
import vista.MenuAdminResidenteBorrar;
import vista.MenuAdminResidenteBuscar;
import vista.MenuAdminResidenteCrear;
import vista.menuLogin;

/**
 *
 * @author kamiz
 */
public class ControladorAdmin implements ActionListener{
    
    //Hacemos referencia a la clase UsuarioDAO
    UsuarioDAO ud = new UsuarioDAO();
    //Hacemos referencia a las 3 ventanas de crear en Java
    MenuAdminBuscar ma = new MenuAdminBuscar();
    MenuAdminCrear mac = new MenuAdminCrear();
    MenuAdminBorrar mab = new MenuAdminBorrar();
    MenuAdminResidenteBorrar marb = new MenuAdminResidenteBorrar();
    MenuAdminResidenteBuscar marbu = new MenuAdminResidenteBuscar();  
    MenuAdminResidenteCrear marc = new MenuAdminResidenteCrear();
    menuLogin mg = new menuLogin();
    
    UsuarioVO uv = new UsuarioVO();
    MenuAdminPrincipal map = new MenuAdminPrincipal();
    public int id =0;
   

    public ControladorAdmin(UsuarioDAO ud, MenuAdminBuscar ma, UsuarioVO uv, MenuAdminPrincipal map, MenuAdminCrear mac, MenuAdminBorrar mab, MenuAdminResidenteBorrar marb, MenuAdminResidenteBuscar marbu, MenuAdminResidenteCrear marc, menuLogin ml) {
        this.marb = marb;
        this.mg = ml;
        this.marc = marc;
        this.marbu = marbu;
        this.map= map;
        this.mac = mac;
        this.mab = mab;
        this.ud = ud;
        this.ma = ma;
        this.uv = uv;
        
        this.map.jbtnCrear.addActionListener(this);
        this.map.jbtnEditar.addActionListener(this);
        this.map.jbtnEliminar.addActionListener(this);
        this.map.jbtnCrearRes.addActionListener(this);
        this.map.jbtnEditarRes.addActionListener(this);
        this.map.jbtnEliminarRes.addActionListener(this);
        this.map.jbtnCerrarSesion.addActionListener(this);
        
        this.ma.jbtnEditar.addActionListener(this);
        this.ma.jbtnBuscar.addActionListener(this);
        
        this.mac.jbtnCrear.addActionListener(this);
        
        this.mab.jbtnBorrar.addActionListener(this);
        this.mab.jbtnBuscar.addActionListener(this);
        
       
    }
    
    private void insertar(){
        uv.setNombre(mac.jtxtNombre.getText());
        uv.setApellido(mac.jtxtApellido.getText());
        uv.setUsuario(mac.jtxtUsuario.getText());
        uv.setPassw(mac.jtxtPassw.getText());
        uv.setEstado(mac.jcmboEstadoUsuario.getSelectedIndex());
        uv.setAcceso(mac.jcmboAcceso.getSelectedIndex()+1);
        ud.insertarUsuario(uv);
        
        System.out.println("El estado es: "+uv.getEstado());
        System.out.println("El acceso es : "+uv.getAcceso());
    }
    
    private void cargarUsuarioBorrar(){
        String name;
        uv.setId(Integer.parseInt(mab.jtxtID.getText()));
        name = ud.obtenerNombre(uv);
        String nombre = uv.getNombre();
        String apellido = uv.getApellido();
        String usuario = uv.getUsuario();
        String passw = uv.getPassw();
        int acceso = uv.getAcceso();
        int estado = uv.getEstado();
        
        mab.jtxtNombre.setText(nombre);
        mab.jtxtApellido.setText(apellido);
        mab.jtxtPassw.setText(passw);
        mab.jtxtUsuario.setText(usuario);
        mab.jcmboAcceso.setSelectedIndex(acceso-1);
        mab.jcmboEstadoUsuario.setSelectedIndex(estado);
    }
    
    private void cargarUsuarioEditar(){
        String name;
        System.out.println("Se ha presionado un boton");
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
        name = ud.obtenerNombre(uv);
        String nombre = uv.getNombre();
        String apellido = uv.getApellido();
        String usuario = uv.getUsuario();
        String passw = uv.getPassw();
        int acceso = uv.getAcceso();
        int estado = uv.getEstado();
        
        ma.jtxtNombre.setText(nombre);
        ma.jtxtApellido.setText(apellido);
        ma.jtxtPassw.setText(passw);
        ma.jtxtUsuario.setText(usuario);
        ma.jcmboAcceso.setSelectedIndex(acceso-1);
        ma.jcmboEstadoUsuario.setSelectedIndex(estado);
        
        System.out.println(id);
        
        
    }
    
    private void actualizarUsuario(){
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
        uv.setNombre(ma.jtxtNombre.getText());
        uv.setApellido(ma.jtxtApellido.getText());
        uv.setUsuario(ma.jtxtUsuario.getText());
        uv.setPassw(ma.jtxtPassw.getText());
        uv.setAcceso(ma.jcmboAcceso.getSelectedIndex()+1);
        uv.setEstado(ma.jcmboEstadoUsuario.getSelectedIndex());
        ud.modificar(uv);
        
        System.out.println(uv.getId());
        System.out.println(uv.getNombre());
        System.out.println(uv.getApellido());
        System.out.println(uv.getUsuario());
        System.out.println(uv.getPassw());
        System.out.println(uv.getEstado());
        System.out.println(uv.getAcceso());
    }
    
    private void eliminarPorID(){
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
        ud.Eliminar(uv);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == map.jbtnEditar){
            map.setVisible(false);
            this.ma.setVisible(true);
            this.id=uv.getId();
            
        }if(e.getSource()== map.jbtnCrear){
            this.map.setVisible(false);
            this.mac.setVisible(true);
            this.id=uv.getId();
        }if(e.getSource() == map.jbtnEliminar){
            this.map.setVisible(false);
            this.mab.setVisible(true);
            this.id = uv.getId();
            }
        if(e.getSource()== map.jbtnCrearRes){
            this.id = uv.getId();
            this.map.setVisible(false);
            this.marc.setVisible(true);
        }
        if(e.getSource()== map.jbtnEditarRes){
            this.id = uv.getId();
            this.map.setVisible(false);
            this.marbu.setVisible(true);
        }
        if(e.getSource()== map.jbtnEliminarRes){
            this.id = uv.getId();
            this.map.setVisible(false);
            this.marb.setVisible(true);
        }
        if(e.getSource() == map.jbtnCerrarSesion){
            this.map.setVisible(false);
            this.mg.setVisible(true);
            this.mg.jtxtUsername.setText("");
            this.mg.jPassw.setText("");
        }
    }
    
}
