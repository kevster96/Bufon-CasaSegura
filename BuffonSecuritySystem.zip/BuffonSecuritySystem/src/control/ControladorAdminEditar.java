/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminBuscar;
import vista.MenuAdminPrincipal;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorAdminEditar implements ActionListener, WindowListener, MouseListener{
    
    UsuarioDAO ud = new UsuarioDAO();
    UsuarioVO uv = new UsuarioVO();
    MenuAdminBuscar ma = new MenuAdminBuscar();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();
    
    public ControladorAdminEditar(UsuarioDAO ud, UsuarioVO uv, MenuAdminBuscar ma, MenuAdminPrincipal mp, menuLogin lg){
        this.ud = ud;
        this.ml = lg;
        this.mp=mp;
        this.uv = uv;
        this.ma= ma;
        
        this.ma.jbtnBuscar.addActionListener(this);
        this.ma.jbtnEditar.addActionListener(this);
        
        this.ma.jbtnCerrarSesion.addActionListener(this);
        this.ma.jbtnMenuPrincipal.addActionListener(this);
        this.ma.jtable.addMouseListener(this);
        
        this.ma.addWindowListener(this);
    }
    

    
        private void cargarUsuarioBorrar(){
        String name;
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
        name = ud.obtenerNombre(uv);
        String nombre = uv.getNombre();
        String apellido = uv.getApellido();
        String usuario = uv.getUsuario();
        String passw = uv.getPassw();
        int acceso = uv.getAcceso();
        int estado = uv.getEstado();
        
        ma.jtxtNombre.setText(nombre);
        ma.jtxtApellido.setText(apellido);
        ma.jtxtPassw.setText(passw);
        ma.jtxtUsuario.setText(usuario);
        ma.jcmboAcceso.setSelectedIndex(acceso-1);
        ma.jcmboEstadoUsuario.setSelectedIndex(estado);
    }
    
        private boolean actualizarUsuario(){
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
        uv.setNombre(ma.jtxtNombre.getText());
        uv.setApellido(ma.jtxtApellido.getText());
        uv.setUsuario(ma.jtxtUsuario.getText());
        uv.setPassw(ma.jtxtPassw.getText());
        uv.setAcceso(ma.jcmboAcceso.getSelectedIndex()+1);
        uv.setEstado(ma.jcmboEstadoUsuario.getSelectedIndex());
        ud.modificar(uv);
        
          return true;
    }

        
    private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Acceso");
            
            for(UsuarioVO v : this.ud.consultarTabla()){
                m.addRow(new Object[]{v.getId(), v.getNombre(), v.getApellido(), v.getUsuario(),
                v.getPassw(), v.getEstado(), v.getAcceso()});
            }
            ma.jtable.setModel(m);
        }
    
    
    public void getFila(){
        int row= ma.jtable.getSelectedRow();
        String value = String.valueOf(ma.jtable.getValueAt(row, 0));
        
        String value2 = String.valueOf(ma.jtable.getValueAt(row, 1));
        
        String value3 = String.valueOf(ma.jtable.getValueAt(row, 2));
        
        String value4 = String.valueOf(ma.jtable.getValueAt(row, 3));
        
        String value5 = String.valueOf(ma.jtable.getValueAt(row, 4));
        
        String value6 = String.valueOf(ma.jtable.getValueAt(row, 5));
        
        String value7 = String.valueOf(ma.jtable.getValueAt(row, 6));
        
        int estado = Integer.parseInt(value6);
        int acceso = Integer.parseInt(value7);
        ma.jtxtID.setText(value);
        ma.jtxtNombre.setText(value2);
        ma.jtxtApellido.setText(value3);
        ma.jtxtUsuario.setText(value4);
        ma.jtxtPassw.setText(value5);
        ma.jcmboAcceso.setSelectedIndex(acceso+1);
        ma.jcmboEstadoUsuario.setSelectedIndex(estado);
        
        uv.setId(Integer.parseInt(ma.jtxtID.getText()));
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== ma.jbtnBuscar){
            this.mostrarDB();
            try{
            this.cargarUsuarioBorrar();
            this.mostrarDB();
              }catch(Exception a){
                ma.jOptionGuardar.showMessageDialog(null, "Ha ocurrido un error, detalles: "+a);
            }
        }
        if(e.getSource() == ma.jbtnEditar){
            this.mostrarDB();
            try{
           if(this.actualizarUsuario() == true){
               ma.jOptionGuardar.showMessageDialog(null, "Se ha actualizado el usuario con ID "+uv.getId());      
               this.mostrarDB();
           }else{
               ma.jOptionGuardar.showMessageDialog(null, "No se ha actualizado el usuario");
           }
            }catch(Exception a){
                ma.jOptionGuardar.showMessageDialog(null, "Ha ocurrido un error, detalles: "+a);
            }
        }
        if(e.getSource()== ma.jbtnCerrarSesion){
            ma.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }
        if(e.getSource() == ma.jbtnMenuPrincipal){
            ma.setVisible(false);
            mp.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.getFila();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        
    }

    @Override
    public void windowClosed(WindowEvent e) {
        
    }

    @Override
    public void windowIconified(WindowEvent e) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        
    }

    @Override
    public void windowActivated(WindowEvent e) {
        
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        
    }
}
