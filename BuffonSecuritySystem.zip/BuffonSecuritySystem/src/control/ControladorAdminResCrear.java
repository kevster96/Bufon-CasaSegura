/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminPrincipal;
import vista.MenuAdminResidenteCrear;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorAdminResCrear implements ActionListener, MouseListener, WindowListener{
    
    UsuarioVO uv = new UsuarioVO();
    UsuarioDAO ud = new UsuarioDAO();
    
    MenuAdminResidenteCrear marc = new MenuAdminResidenteCrear();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();
    int id=0;
    public ControladorAdminResCrear(UsuarioVO uv, UsuarioDAO ud, MenuAdminResidenteCrear marc, MenuAdminPrincipal mp, menuLogin ml){
        this.uv = uv;
        this.ud = ud;
        this.mp=mp;
        this.ml=ml;
        this.marc = marc;
        
        this.marc.jbtnCrear.addActionListener(this);
        this.marc.jbtnCerrarSesion.addActionListener(this);
        this.marc.jbtnMenuPrincipal.addActionListener(this);
        
        this.marc.jtable.addMouseListener(this);
        this.marc.addWindowListener(this);
    }
    
        private boolean checkEmpty(){
                
        
        if("".equals(uv.getNombre())){
            marc.joptionCrear.showMessageDialog(null, "No ha ingresado el nombre");
            return false;
        }
        if("".equals(uv.getApellido())){
            marc.joptionCrear.showMessageDialog(null, "No ha ingresado el apellido");
            return false;
        }
        if("".equals(uv.getUsuario())){
            marc.joptionCrear.showMessageDialog(null, "No ha ingresado el usuario");
            return false;
        }
        if("".equals(uv.getPassw())){
            marc.joptionCrear.showMessageDialog(null, "No ha ingresado la contraseña");
            return false;
        }
        if(uv.getPassw().length()<8){
            marc.joptionCrear.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        if(uv.getPassw().length()>20){
            marc.joptionCrear.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        else{
            return true;
        }
    }

    public void crearUsuario(){
        uv.setNombre(marc.jtxtNombre.getText());
        uv.setApellido(marc.jtxtApellido.getText());
        uv.setEstado(marc.jcmboEstadoUsuario.getSelectedIndex());
        uv.setUsuario(marc.jtxtUsuario.getText());
        uv.setPassw(marc.jtxtPassw.getText());
        System.out.println(uv.getId());
        this.id = uv.getId();
        uv.setId(id);
        if(this.checkEmpty()){
            if(ud.validarResidente(uv)== true){
                marc.joptionCrear.showMessageDialog(null, "El usuario "+uv.getUsuario()+" ya existe, elija uno nuevo");
            }else{
                ud.insertarResidente(uv);
                marc.joptionCrear.showMessageDialog(null, "Se ha creado el usuario "+uv.getUsuario()+" exitosamente");
            }
        }
        
    }
    private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Administrador ID");
            
            for(UsuarioVO uv : this.ud.consultarResidente()){
                m.addRow(new Object[]{uv.getId(), uv.getNombre(), uv.getApellido(), uv.getUsuario(),
                uv.getPassw(), uv.getEstado(), uv.getFk_usuario()});
            }
            marc.jtable.setModel(m);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== marc.jbtnCrear){

            this.crearUsuario();     
            this.mostrarDB();
        }
        if(e.getSource() == marc.jbtnCerrarSesion){
            marc.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }if(e.getSource()== marc.jbtnMenuPrincipal){
            marc.setVisible(false);
            mp.setVisible(true);
        }
    }
    


    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        
    }

    @Override
    public void windowClosed(WindowEvent e) {
        
    }

    @Override
    public void windowIconified(WindowEvent e) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        
    }

    @Override
    public void windowActivated(WindowEvent e) {
        
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        
    }
    
    
}
