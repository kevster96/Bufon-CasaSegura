/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 *
 * @author kamiz
 */

//Clase para hacer la conexion a la base de Datos
public class BaseDeDatos { 
    //Hacemos referencia con la variable Driver al driver de Java hacia mysql
    private String driver = "com.mysql.jdbc.Driver";
    //Variable servidor hace referencia al nombre del server "localhost"
    private String  servidor     = "servidor-mysql-2021.mysql.database.azure.com";
    //hacemos referencia al usuario de la base de datos
    private String  usuario     = "user2020@servidor-mysql-2021";
    //referencia a la contraseña de la base de datos
    private String  password       = "Intecap2020.";
    //Referencia al nombre de la base de datos.
    private String db = "bd_buffon";
    //Utilizamos la variable cadena para inicializar los querys a mysql
    private String cadena;
    
    //Declaracion del objeto que permite conectarnos.
    Connection con;
    
    //Declaracion del objeto que permite interactuar con codigo SQL
    Statement st;
    
    // Metodo de conectar, nos inicia la conexion a la base de datos
    //utilizamos la variable cadena para hacer referencia al servidor y la base de datos
    public void conectar(){
        this.cadena = "jdbc:mysql://"+this.servidor+"/"+this.db;
        
        try{
            //se inicia la conexion a la base de datos
            Class.forName(this.driver).newInstance();
            this.con=DriverManager.getConnection(this.cadena,this.usuario,this.password);
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
    }
    
    //Se utiliza para hacer consultas a la base de datos
    //podemos utilizarla para crear difernetes querys en mysql como
    //un Alter, un drop, un delete, etc
    public int consulta_multi (String consulta){
        int resultado;
        try{
            this.conectar();
            this.st = con.createStatement();
            
            resultado = this.st.executeUpdate(consulta);
        } catch(Exception e){
            System.err.println(e);
            return 0;
        }
        return resultado;
    }
    
    // Metodo que nos funciona para obtener informacion de la base de datos
    public ResultSet consulta_obtener (String consulta){
        try{
            this.conectar();
            ResultSet respuesta = null;
            this.st = this.con.createStatement();
            respuesta = st.executeQuery(consulta);
            return respuesta;
            
        }catch(Exception e){
            System.err.println(e);
        }
        return null;
    }
    
    //Terminamos la conexion a la base de datos.
    public void desconectar(){
        try {
            con.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}
