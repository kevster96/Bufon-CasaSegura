/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminPrincipal;
import vista.MenuAdminResidenteBorrar;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorAdminResBorrar implements ActionListener, MouseListener, WindowListener{
    
    UsuarioVO uv = new UsuarioVO();
    UsuarioDAO ud = new UsuarioDAO();
    int id;
    MenuAdminResidenteBorrar marb = new MenuAdminResidenteBorrar();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();

    public ControladorAdminResBorrar(UsuarioVO uv, UsuarioDAO ud, MenuAdminResidenteBorrar marb, MenuAdminPrincipal mp, menuLogin ml){
        this.uv = uv;
        this.ud = ud;
        this.marb=marb;
        this.mp = mp;
        this.ml = ml;
        this.marb.jbtnBorrar.addActionListener(this);
        this.marb.jbtnBuscar.addActionListener(this);
        
        this.marb.jbtnCerrarSesion.addActionListener(this);
        this.marb.jbtnMenuPrincipal.addActionListener(this);
        
        this.marb.jtable.addMouseListener(this);
        this.marb.addWindowListener(this);
    }
    
    private boolean isEmpty(){
        if("".equals(uv.getId())){
            marb.jOptionBorrar.showMessageDialog(null, "Por favor ingrese el ID");
            return false;

        }
        
         /**if("".equals(uv.getNombre())){
            marb.jOptionBorrar.showMessageDialog(null, "Por favor ingrese el nombre");
            return false;
        }
        if("".equals(uv.getApellido())){
            marb.jOptionBorrar.showMessageDialog(null, "Por favor ingrese el apellido");
            return false;
        }if("".equals(uv.getPassw())){
            marb.jOptionBorrar.showMessageDialog(null, "Por favor ingrese la nueva contraseña");
            return false;
        }
        if("".equals(uv.getUsuario())){
            marb.jOptionBorrar.showMessageDialog(null, "Por favor ingrese el usuario");
            return false;
        */else{
            return true;
        }
    }
    private void obtenerResidente(){
        id=uv.getId();
        uv.setId(Integer.parseInt(this.marb.jtxtID.getText()));
        if(isEmpty()){
            ud.obtenerResidente(uv);
        marb.jtxtNombre.setText(uv.getNombre());
        marb.jtxtApellido.setText(uv.getApellido());
        marb.jtxtPassw.setText(uv.getPassw());
        marb.jtxtUsuario.setText(uv.getUsuario());
        marb.jcmboEstadoUsuario.setSelectedIndex(uv.getEstado()); 
        
        uv.setUsuario(marb.jtxtUsuario.getText());
        }else{
            marb.jOptionBorrar.showMessageDialog(null, "Por favor valide el ID ingresado");
        }
    }
    
    private void eliminarResidente(){
        uv.setId(Integer.parseInt(marb.jtxtID.getText()));
        if(isEmpty()){
        ud.eliminarResidente(uv);
        }else{
            marb.jOptionBorrar.showMessageDialog(null, "Por favor valide el ID ingresado");
        }
        
    }
    
       private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Admin ID");
            
            for(UsuarioVO uv : this.ud.consultarResidente()){
                m.addRow(new Object[]{uv.getId(), uv.getNombre(), uv.getApellido(), uv.getUsuario(),
                uv.getPassw(), uv.getEstado(), uv.getFk_usuario()});
            }
            marb.jtable.setModel(m);
        }
    
       public void getFila(){
        int row= marb.jtable.getSelectedRow();
        String value = String.valueOf(marb.jtable.getValueAt(row, 0));
        
        String value2 = String.valueOf(marb.jtable.getValueAt(row, 1));
        
        String value3 = String.valueOf(marb.jtable.getValueAt(row, 2));
        
        String value4 = String.valueOf(marb.jtable.getValueAt(row, 3));
        
        String value5 = String.valueOf(marb.jtable.getValueAt(row, 4));
        
        String value6 = String.valueOf(marb.jtable.getValueAt(row, 5));
        
        
        int estado = Integer.parseInt(value6);
        marb.jtxtID.setText(value);
        marb.jtxtNombre.setText(value2);
        marb.jtxtApellido.setText(value3);
        marb.jtxtUsuario.setText(value4);
        marb.jtxtPassw.setText(value5);
    }
       
       
       
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== marb.jbtnBorrar){
            try{
            this.eliminarResidente();          
            this.mostrarDB();
            marb.jOptionBorrar.showMessageDialog(null, "Ha eliminado el usuario: "+uv.getUsuario()+ " exitosamente");
            }catch(Exception a){
                marb.jOptionBorrar.showMessageDialog(null, "Ha ocurrido un error ineseperado: "+a);
            }
            
        }
        if(e.getSource()==marb.jbtnBuscar){
            try{
            this.obtenerResidente();
            this.mostrarDB();
            }catch(Exception a){
                marb.jOptionBorrar.showMessageDialog(null, "Ha ocurrido un error ineseperado: "+a);
            }
        }
        if(e.getSource() == marb.jbtnCerrarSesion){
            marb.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }if(e.getSource()== marb.jbtnMenuPrincipal){
            marb.setVisible(false);
            mp.setVisible(true);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        this.getFila();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
        
    }

    @Override
    public void windowClosed(WindowEvent e) {
        
    }

    @Override
    public void windowIconified(WindowEvent e) {
        
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        
    }

    @Override
    public void windowActivated(WindowEvent e) {
        
    }

    @Override
    public void windowDeactivated(WindowEvent e) {
        
    }
}
