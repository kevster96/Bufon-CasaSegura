/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.table.DefaultTableModel;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminCrear;
import vista.MenuAdminPrincipal;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorAdminCrear implements ActionListener, WindowListener{
    
    UsuarioDAO ud = new UsuarioDAO();
    UsuarioVO uv = new UsuarioVO();
    MenuAdminCrear mac = new MenuAdminCrear();
    MenuAdminPrincipal mp = new MenuAdminPrincipal();
    menuLogin ml = new menuLogin();
    
    public ControladorAdminCrear(UsuarioDAO ud, UsuarioVO uv, MenuAdminCrear mac, MenuAdminPrincipal mp, menuLogin ml){
        this.ud = ud;
        this.uv = uv;
        this.mac = mac;
        this.mp= mp;
        this.ml=ml;
        
        this.mac.jbtnCrear.addActionListener(this);
        this.mac.jbtnCerrarSesion.addActionListener(this);
        this.mac.jbtnMenuPrincipal.addActionListener(this);
        this.mac.addWindowListener(this);
        
        
    }

    private boolean checkEmpty(){
                
        
        if("".equals(uv.getNombre())){
            mac.joptionMessage.showMessageDialog(null, "No ha ingresado el nombre");
            return false;
        }
        if("".equals(uv.getApellido())){
            mac.joptionMessage.showMessageDialog(null, "No ha ingresado el apellido");
            return false;
        }
        if("".equals(uv.getUsuario())){
            mac.joptionMessage.showMessageDialog(null, "No ha ingresado el usuario");
            return false;
        }
        if("".equals(uv.getPassw())){
            mac.joptionMessage.showMessageDialog(null, "No ha ingresado la contraseña");
            return false;
        }
        if(uv.getPassw().length()<8){
            mac.joptionMessage.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        if(uv.getPassw().length()>20){
            mac.joptionMessage.showMessageDialog(null, "La contraseña debe ser entre 8 a 20 caracteres");
            return false;
        }
        else{
            return true;
        }
    }
    
    private void insertar(){
        try{
        uv.setNombre(mac.jtxtNombre.getText());
        uv.setApellido(mac.jtxtApellido.getText());
        uv.setUsuario(mac.jtxtUsuario.getText());
        uv.setPassw(mac.jtxtPassw.getText());
        uv.setEstado(mac.jcmboEstadoUsuario.getSelectedIndex());
        uv.setAcceso(mac.jcmboAcceso.getSelectedIndex()+1);
        
        if(this.checkEmpty()){
            if(ud.validarUsuario(uv)==true){
                mac.joptionMessage.showMessageDialog(null, "El usuario "+uv.getUsuario()+" ya existe");
            }
            else{
                ud.insertarUsuario(uv);
                mac.joptionMessage.showMessageDialog(null, "Se ha agregado el usuario "+uv.getUsuario()+ " correctamente");
            }
            
        }
        
        }catch(Exception e){
            mac.joptionMessage.showMessageDialog(null, "Se ha producido un error"+e);
        }
    }
        private void mostrarDB(){
            DefaultTableModel m = new DefaultTableModel();
            m.setColumnCount(0);
            m.addColumn("ID empleado");
            m.addColumn("nombre");
            m.addColumn("apellido");
            m.addColumn("usuario");
            m.addColumn("contraseña");
            m.addColumn("Activo");
            m.addColumn("Acceso");
            
            for(UsuarioVO v : this.ud.consultarTabla()){
                m.addRow(new Object[]{v.getId(), v.getNombre(), v.getApellido(), v.getUsuario(),
                v.getPassw(), v.getEstado(), v.getAcceso()});
            }
            mac.jTable.setModel(m);
        }

        
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== mac.jbtnCrear){
            this.insertar();
            this.mostrarDB();
        }
        if(e.getSource()==mac.jbtnCerrarSesion){
            mac.setVisible(false);
            ml.setVisible(true);
            this.ml.jtxtUsername.setText("");
            this.ml.jPassw.setText("");
        }
        if(e.getSource() == mac.jbtnMenuPrincipal){
            mac.setVisible(false);
            mp.setVisible(true);
        }
    }

    @Override
    public void windowOpened(WindowEvent e) {
        this.mostrarDB();
    }

    @Override
    public void windowClosing(WindowEvent e) {
    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }

}
