/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.UsuarioDAO;
import modelo.UsuarioVO;
import vista.MenuAdminPrincipal;
import vista.menuLogin;
import vista.menuPrincipal;

/**
 *
 * @author kamiz
 */
public class ControladorLogin implements ActionListener{

     menuLogin lg = new menuLogin();
     UsuarioVO uvo = new UsuarioVO();
     UsuarioDAO udao = new UsuarioDAO();
     MenuAdminPrincipal map = new MenuAdminPrincipal();
     menuPrincipal mp = new menuPrincipal();
     
     public int id_login;
            
    public ControladorLogin(menuLogin lg, UsuarioVO uvo, UsuarioDAO udao, MenuAdminPrincipal map, menuPrincipal mp){
        this.map=map;
        this.mp=mp;
        this.lg = lg;
        this.uvo=uvo;
        this.udao=udao;
        this.lg.jbtnLogin.addActionListener(this);
    }
    
    
    
    private void validarAcceso(){
        int vista =0;
        int id = 0;
        int estado = 3;
        this.uvo.setUsuario(this.lg.jtxtUsername.getText());
        this.uvo.setPassw(this.lg.jPassw.getText());
        estado = this.udao.validarEstado(uvo);
        vista= this.udao.validarAcceso(uvo);
        id = this.udao.obtenerID(uvo);
        this.uvo.setId(id);
        this.id_login = id;
        
        if(this.udao.validarExiste(uvo) == true){
            if(estado==1){
                lg.jpaneAcceso.showMessageDialog(null, "Bienvenido");
            if(vista==1){
                this.lg.setVisible(false);
                this.map.setVisible(true);
            }if(vista == 2){
                this.lg.setVisible(false);
                this.mp.setVisible(true);
            }
                
            
            }if(estado==2){
                lg.jpaneAcceso.showMessageDialog(null, "El usuario esta inactivo");
            }
            }else{
                this.lg.setVisible(true);
                lg.jpaneAcceso.showMessageDialog(null,"Usuario o contraseña incorrecta");
        }
        
    }
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource()==lg.jbtnLogin){
           
           this.validarAcceso();
           this.id_login = uvo.getId();
       }
    }
    
}
