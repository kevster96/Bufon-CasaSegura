/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author kamiz
 */
public class VisitaVO {
    
    private int fk_usuario;
    private String nombre;
    private String apellido;
    private String token;
    private long DPI; 
    private int entradasalida;
    private String fecha;

    public int getEntradasalida() {
        return entradasalida;
    }

    public void setEntradasalida(int entradasalida) {
        this.entradasalida = entradasalida;
    }
    public String getToken() {
        return token;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    
    public void setToken(String token) {
        this.token = token;
    }

    public int getFk_usuario() {
        return fk_usuario;
    }

    public void setFk_usuario(int fk_usuario) {
        this.fk_usuario = fk_usuario;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public long getDPI() {
        return DPI;
    }

    public void setDPI(long DPI) {
        this.DPI = DPI;
    }

    public VisitaVO() {
        this.nombre = nombre;
        this.apellido = apellido;
        this.DPI = DPI;
        this.entradasalida = entradasalida;
        this.fk_usuario = fk_usuario;
        this.token = token;
    }
    
}
