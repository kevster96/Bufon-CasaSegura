/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import control.BaseDeDatos;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author kamiz
 */
public class UsuarioDAO implements ConsultasDAO{
    
    int id_usuario;
    
    
    @Override
    public boolean validarExiste(UsuarioVO u) {
        BaseDeDatos c = new BaseDeDatos();
        
        boolean existe= false;
        
        try{
            c.conectar();
            ResultSet rs = c.consulta_obtener("SELECT * FROM tblempleado WHERE "
                    + "usuario='"+u.getUsuario()+"' and contrasena='"+u.getPassw()
                            +"';");
            if(rs.next()){
                existe=true;
                return existe;
            }else{
                return existe;
            }
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return existe;
    }

    @Override
    public int validarEstado(UsuarioVO u) {
        int activo = 2;
        
        BaseDeDatos c = new BaseDeDatos();
        
        UsuarioVO eVO = new UsuarioVO();
        try{
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT usuario_activo FROM tblempleado "
                            + "WHERE usuario='"+u.getUsuario()+"' "
                            + "and contrasena='"+u.getPassw()+"';");
            
            while(rs.next()){
                eVO.setAcceso(rs.getInt(1));
            }
            activo = eVO.getAcceso();
            if(activo ==1){
                return activo;
            }else{
                
            }
            
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return activo;
    }
    
    public void insertarUsuario(UsuarioVO u){
        BaseDeDatos c = new BaseDeDatos();
        
        try {
            c.conectar();
            c.consulta_multi("INSERT INTO tblempleado (nombre, apellido,usuario, contrasena, usuario_activo,"
                    + "fk_acceso) VALUES ('"+u.getNombre()+"','"+u.getApellido()+"','"
                            + u.getUsuario()+"','"+u.getPassw()+"',"+u.getEstado()+","
                                    +u.getAcceso()+ ");");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
        c.desconectar(); 
    }

    @Override
    public String obtenerNombre(UsuarioVO u) {
        BaseDeDatos c = new BaseDeDatos();
        String nombre= "";
        String apellido = "";
        String usuario = "";
        String passw = "";
        int acceso =0;
        int activo = 0;
        
        try {
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT nombre, apellido"
                    + ", usuario, contrasena, usuario_activo, fk_acceso from tblempleado where id_tblempleado="+u.getId());
            
            while(rs.next()){
                u.setNombre(rs.getString(1));
                u.setApellido(rs.getString(2));
                u.setUsuario(rs.getString(3));
                u.setPassw(rs.getString(4));
                u.setEstado(rs.getInt(5));
                u.setAcceso(rs.getInt(6));
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
        return nombre;
    }

    @Override
    public void Eliminar(UsuarioVO v) {
       BaseDeDatos c = new BaseDeDatos();
       
        try {
            c.conectar();
            
            c.consulta_multi("DELETE FROM tblempleado where id_tblempleado="+v.getId());
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }

    @Override
    public void modificar(UsuarioVO v) {
        BaseDeDatos c = new BaseDeDatos();
        
        try {
            c.conectar();
            
            c.consulta_multi("UPDATE tblempleado SET nombre='"+v.getNombre()+"', apellido='"+v.getApellido()+"', usuario='"+v.getUsuario()+"', contrasena='"+v.getPassw()+"', usuario_activo="+v.getEstado()+
            ",fk_acceso="+v.getAcceso()+" WHERE id_tblempleado="+v.getId());
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }

    @Override
    public int validarAcceso(UsuarioVO u) {
                int estado = 2;
        
        BaseDeDatos c = new BaseDeDatos();
        
        UsuarioVO eVO = new UsuarioVO();
        try{
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT id_tblempleado, fk_acceso FROM tblempleado "
                            + "WHERE usuario='"+u.getUsuario()+"' "
                            + "and contrasena='"+u.getPassw()+"';");
            
            while(rs.next()){
                eVO.setAcceso(rs.getInt(2));
                eVO.setId(rs.getInt(1));
            }
            estado = eVO.getAcceso();
            id_usuario = eVO.getId();
            eVO.setId(id_usuario);
            if(estado ==1){
                return estado;
            }else{
                
            }
            
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return estado;
    }

    @Override
    public void insertarResidente(UsuarioVO u) {
        
        BaseDeDatos c = new BaseDeDatos();
        try {
            c.conectar();
            c.consulta_multi("INSERT INTO tblusuario (nombre, apellido,usuario, contrasena, usuario_activo,"
                    + "fk_empleado) VALUES ('"+u.getNombre()+"','"+u.getApellido()+"','"
                            + u.getUsuario()+"','"+u.getPassw()+"',"+u.getEstado()+","
                                    +u.getId()+ ");");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
        c.desconectar(); 
        }

    @Override
    public int obtenerID(UsuarioVO u) {
        int id = 0;
        
        BaseDeDatos c = new BaseDeDatos();
        
        UsuarioVO eVO = new UsuarioVO();
        try{
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT id_tblempleado FROM tblempleado "
                            + "WHERE usuario='"+u.getUsuario()+"' "
                            + "and contrasena='"+u.getPassw()+"';");
            
            while(rs.next()){
                eVO.setId(rs.getInt(1));
            }
            
            id = eVO.getId();
            eVO.setId(id);
            
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return id;
        }   

    @Override
    public void obtenerResidente(UsuarioVO u) {
                BaseDeDatos c = new BaseDeDatos();
        String nombre= "";
        String apellido = "";
        String usuario = "";
        String passw = "";
        int acceso =0;
        
        
        try {
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT nombre, apellido"
                    + ", usuario, contrasena, usuario_activo from tblusuario where id_tblusuario="+u.getId());
            
            while(rs.next()){
                u.setNombre(rs.getString(1));
                u.setApellido(rs.getString(2));
                u.setUsuario(rs.getString(3));
                u.setPassw(rs.getString(4));
                u.setEstado(rs.getInt(5));
                
            }
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
 
    }
    

    @Override
    public void eliminarResidente(UsuarioVO u) {
               BaseDeDatos c = new BaseDeDatos();
       
        try {
            c.conectar();
            
            c.consulta_multi("DELETE FROM tblusuario where id_tblusuario="+u.getId());
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
    }

    @Override
    public void modificarResidente(UsuarioVO u) {
                BaseDeDatos c = new BaseDeDatos();
                UsuarioVO v = new UsuarioVO ();
        try {
            c.conectar();
            
            c.consulta_multi("UPDATE tblusuario SET nombre='"+u.getNombre()+"', apellido='"+u.getApellido()+"', usuario='"+u.getUsuario()+"', contrasena='"+u.getPassw()+"', usuario_activo="+u.getEstado()+
            ",fk_empleado="+u.getFk_usuario()+" WHERE id_tblusuario="+u.getId());
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        c.desconectar();
        }

    @Override
    public boolean validarUsuario(UsuarioVO u) {
        BaseDeDatos c = new BaseDeDatos();
        boolean existe = false;
        String user ;
        try{
            ResultSet rs = c.consulta_obtener("SELECT usuario from tblempleado WHERE usuario ='"+u.getUsuario()+"';");
            
            while(rs.next()){
                u.setUsuario(rs.getString(1));
                if("".equals(u.getUsuario())){
                    existe = false;
                }else{
                    existe = true;
                }
                
            }
            user = u.getUsuario();
        }catch(Exception e){
            System.err.println(e);
        }
        return existe;
    }

    @Override
    public boolean validarResidente(UsuarioVO u) {
        BaseDeDatos c = new BaseDeDatos();
        boolean existe= false;
        String user ;
        try{
            ResultSet rs = c.consulta_obtener("SELECT usuario from tblusuario WHERE usuario='"+u.getUsuario()+"';");
            
            while(rs.next()){
                u.setUsuario(rs.getString(1));
                if("".equals(u.getUsuario())){
                    existe = false;
                }else{
                    existe = true;
                }
                
            }            
        }catch(Exception e){
            System.err.println(e);
        }
        return existe;
    }

    @Override
    public ArrayList<UsuarioVO> consultarTabla() {
        BaseDeDatos c = new BaseDeDatos();
        ArrayList<UsuarioVO> info = new ArrayList<>();
        
        try{
            c.conectar();
            ResultSet rs = c.consulta_obtener("SELECT * FROM tblempleado");
            
            while(rs.next()){
                UsuarioVO v = new UsuarioVO();
                v.setId(rs.getInt(1));
                v.setNombre(rs.getString(2));
                v.setApellido(rs.getString(3));
                v.setUsuario(rs.getString(4));
                v.setPassw(rs.getString(5));
                v.setEstado(rs.getInt(6));
                v.setAcceso(rs.getInt(7));
                
                info.add(v);
            }
            
            
        }catch(Exception e){
            System.err.println(e);
        }
        return info;
    }
        public ArrayList<UsuarioVO> consultarResidente() {
        BaseDeDatos c = new BaseDeDatos();
        ArrayList<UsuarioVO> info = new ArrayList<>();
        
        try{
            c.conectar();
            ResultSet rs = c.consulta_obtener("SELECT * FROM tblusuario");
            
            while(rs.next()){
                UsuarioVO v = new UsuarioVO();
                v.setId(rs.getInt(1));
                v.setNombre(rs.getString(2));
                v.setApellido(rs.getString(3));
                v.setUsuario(rs.getString(4));
                v.setPassw(rs.getString(5));
                v.setEstado(rs.getInt(6));
                v.setFk_usuario(rs.getInt(7));
                
                info.add(v);
            }
            
            
        }catch(Exception e){
            System.err.println(e);
        }
        return info;
    }

    }


