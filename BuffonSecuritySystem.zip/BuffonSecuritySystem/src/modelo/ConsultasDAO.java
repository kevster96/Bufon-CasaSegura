/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author kamiz
 */
public interface ConsultasDAO {
    
    public ArrayList<UsuarioVO> consultarTabla();
    public boolean validarExiste(UsuarioVO u);
    public int obtenerID(UsuarioVO u);
    public int validarAcceso(UsuarioVO u);
    public int validarEstado(UsuarioVO u);
    public void insertarUsuario(UsuarioVO u);
    public String obtenerNombre(UsuarioVO u);
    
    public boolean validarUsuario(UsuarioVO u);
    
    public boolean validarResidente(UsuarioVO u);
    
    public ArrayList<UsuarioVO> consultarResidente();
    public void insertarResidente(UsuarioVO u);
    public void obtenerResidente(UsuarioVO u);
    public void eliminarResidente(UsuarioVO u);
    public void modificarResidente(UsuarioVO u);
    
    public void Eliminar(UsuarioVO v);
    public void modificar(UsuarioVO v);
    
}
