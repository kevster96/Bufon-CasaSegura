/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import control.BaseDeDatos;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 *
 * @author kamiz
 */
public class VisitaDAO implements ConsultasUsuarioDAO{


    @Override
    public String getName(VisitaVO v) {
        BaseDeDatos c = new BaseDeDatos();
        String nombre =  "";
        String apellido = "";
        
        String nombreCompleto ="";
        
        VisitaVO nVo = new VisitaVO();
        
        try{
            c.conectar();
            
            ResultSet rs = c.consulta_obtener("SELECT nombre_visitante, apellido_visitante "
                    + "FROM tbltoken WHERE id_tbltoken='"+v.getToken()+"';");
            
            while(rs.next()){
                nVo.setNombre(rs.getString(1));
                nVo.setApellido(rs.getString(2));
                v.setApellido(rs.getString(2));
                v.setNombre(rs.getString(1));
            }
            nombre = nVo.getNombre();
            apellido = nVo.getApellido();
            v.setApellido(apellido);
            v.setNombre(nombre);
            nombreCompleto = nombre+apellido;
            return nombreCompleto;
        }catch(Exception e){
            System.err.println(e.getMessage());
        }
        return nombreCompleto;
    }

    @Override
    public long getDPI(VisitaVO v) {
        BaseDeDatos c = new BaseDeDatos();
        VisitaVO nVO = new VisitaVO();
        long dpi = 0;
        
        try {
            c.conectar();
            ResultSet rs = c.consulta_obtener("SELECT dpi "
                    + "FROM tbltoken WHERE id_tbltoken='"+v.getToken()+"';");
            while(rs.next()){
                nVO.setDPI(rs.getLong(1));
                v.setDPI(rs.getLong(1));
            }
            dpi = nVO.getDPI();
            v.setDPI(dpi);
            return dpi;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        
        return dpi;
    }
    
    

    @Override
    public void validarVisita(VisitaVO v, UsuarioVO u) {
       BaseDeDatos c = new BaseDeDatos();
       
       Date fecha = new Date();
       
       Calendar calendar = GregorianCalendar.getInstance();
       
       int hora = calendar.get(Calendar.HOUR_OF_DAY);
       int minutes = calendar.get(Calendar.MINUTE);
       int seconds = calendar.get(Calendar.SECOND);
       
       String horaActual = hora+":"+minutes+":"+seconds;
       long millis = System.currentTimeMillis();
       
       java.sql.Date date = new java.sql.Date(millis);
       
       LocalDateTime now = LocalDateTime.now();
        System.out.println(date);
        System.out.println(hora+":"+minutes+":"+seconds);
       //Calendar calendar = Calendar.getInstance();
       //int horas = calendar.get(Calendar.HOUR_OF_DAY);
       
        try {
            c.conectar();
            
            c.consulta_multi("INSERT INTO tblregistro(fk_idtoken, fk_idusuario,fk_idempleado, fk_idtblcheck, hora, fecha) VALUES ('"+v.getToken()+"',"+u.getFk_usuario()+", "+u.getId()+","+v.getEntradasalida()+",'"+horaActual+"','"+date+"');");
            
            
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

    @Override
    public int obtenerUsuarioID(VisitaVO v) {
        BaseDeDatos c = new BaseDeDatos();
        int id = 0;
        try{
            c.conectar();
           ResultSet rs = c.consulta_obtener("SELECT fk_usuario from tbltoken where id_tbltoken='"+v.getToken()+"';");
           
           while(rs.next()){
               v.setFk_usuario(rs.getInt(1));
           }
           id = v.getFk_usuario();
           v.setFk_usuario(id);
           return id;
        }catch(Exception e){
            System.err.println(e.getMessage()); 
        }
        return id;
    }
    

        @Override
    public String obtenerFecha(VisitaVO v) {
        BaseDeDatos c = new BaseDeDatos();
        String fecha = "";
        
        try{
            ResultSet rs = c.consulta_obtener("SELECT fecha from tbltoken where id_tbltoken='"+v.getToken()+"';");
            
            while(rs.next()){
                v.setFecha(rs.getString(1));
                fecha = v.getFecha();
            }
            
        }catch(Exception e){
            System.err.println(e);
        }
        return fecha;
        }
    
}
